﻿#nullable enable
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LittleBigMouse.DisplayLayout.Monitors;

public interface IExcludedListItem
{
    public class Design(string name) : IExcludedListItem
    {
        public string Name { get; } = name;
    }
    string Name { get; }
}

public interface ILayoutOptions : INotifyPropertyChanged // Change IPropertyChange to INotifyPropertyChanged
{
   public class Design : ILayoutOptions
   {
      public string GetConfigPath(string fileName, bool create) => "";

      public double MinimalMaxTravelDistance { get; set; } = 20;
      public double MinimalEdgeOverlap { get; set; } = 20;
      public bool AllowDiscontinuity { get; set; } = false;
      public bool AllowOverlaps { get; set; } = false;
      public bool LoopX { get; set; } = false;
      public bool LoopY { get; set; } = false;
      public double MaxTravelDistance { get; set; } = 200;
      public double FreelookCheckInterval { get; set; } = 100;
      public bool FreelookEnabled { get; set; } = true;
      public bool AdjustPointer { get; set; } = false;
      public bool AdjustSpeed { get; set; } = false;
      public string Algorithm { get; set; } = "Strait";
      public string BorderValues { get; set; } = "PerModel";
      public string RescueShortcut { get; set; } = "Ctrl+Alt+Shift+M";
      public string Priority { get; set; } = "Normal";
      public string PriorityUnhooked { get; set; } = "Below";
      public bool IsUnaryRatio { get; set; } = false;
      public bool Enabled { get; set; } = true;
      public bool AutoUpdate { get; set; } = true;
      public bool LoadAtStartup { get; set; } = false;
      public bool HomeCinema { get; set; } = false;
      public bool Pinned { get; set; } = false;
      public bool StartMinimized { get; set; } = false;
      public bool StartElevated { get; set; } = false;
      public bool HideTrayIcon { get; set; } = false;
      public bool Elevated { get; set; } = true;
      public bool DebugTools { get; set; } = false;
      public bool ExperimentalFeatures { get; set; } = false;
      public bool VcpControl { get; set; } = false;
      public bool ShowMonitorActionWarning { get; set; } = true;

      public bool AdjustSpeedAllowed { get; } = false;
      public ObservableCollection<string> ExcludedList { get; } = new ObservableCollection<string> { "/game/", "/another/game/" };
      public bool Saved { get; set; } = false;
      public bool LoopAllowed { get; } = true;
      public event PropertyChangedEventHandler? PropertyChanged;

      protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
      {
         PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
      }

      protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
      {
         if (EqualityComparer<T>.Default.Equals(field, value)) return false;
         field = value;
         OnPropertyChanged(propertyName);
         return true;
      }
   }

   public string GetConfigPath(string fileName, bool create);

   double MinimalMaxTravelDistance { get; set; }

   /// <summary>
   /// Minimal crossing corridor compaction guarantees between two touching monitors, in mm of
   /// DISPLAY SURFACE shared along the contact edge — bezels excluded, they cannot carry the
   /// cursor. 0 only asks for bezel contact (a corner counts). A layout-editing rule on its
   /// own: it deliberately does NOT look at the crossing algorithm, which belongs to mouse
   /// behaviour — coupling the two would make either option harder to reason about.
   /// </summary>
   double MinimalEdgeOverlap { get; set; }

   /// <summary>
   /// Allow for discontinuities between monitors.
   /// </summary>
   bool AllowDiscontinuity { get; set; }

   /// <summary>
   /// Allow overlaps between monitors.
   /// </summary>
   bool AllowOverlaps { get; set; }

   /// <summary>
   /// Allow mouse cursor looping in X direction
   /// </summary>
   bool LoopX { get; set; }

   /// <summary>
   /// Allow mouse cursor looping in Y direction
   /// </summary>
   bool LoopY { get; set; }


   /// <summary>
   /// Max distance allowed to reach monitor
   /// Helps to prevent cursor to reach monitor too far
   /// </summary>
   double MaxTravelDistance { get; set; }

   /// <summary>
   /// Interval (ms) between freelook re-checks while a game holds the cursor
   /// (hidden or clipped). 0 = re-check on every mouse event.
   /// </summary>
   double FreelookCheckInterval { get; set; }

   /// <summary>
   /// Pause mouse crossing while a game captures the cursor (hidden or clipped).
   /// Off = escape hatch when the detection misfires: some apps hide or confine
   /// the cursor without being games, freezing LBM entirely (#502).
   /// </summary>
   bool FreelookEnabled { get; set; }

   /// <summary>
   /// Adjust pointer size with display pixel to dip ratio
   /// </summary>
   bool AdjustPointer { get; set; }

   /// <summary>
   /// Adjust speed with display pixel to dip ratio
   /// </summary>
   bool AdjustSpeed { get; set; }

   /// <summary>
   /// algorithm to be used for mouse movements
   /// - Strait
   /// - Cross
   /// <para>
   /// These two strings are the WIRE values, and the only ones that mean anything. They are
   /// written verbatim into the saved layouts (layouts/*.json) and into the <c>Algorithm</c>
   /// attribute of the ZonesLayout XML sent to the daemon, which parses them in
   /// <c>rust/crates/lbm-zones/src/layout.rs</c>. Anything else the daemon reads as
   /// "Strait", silently — an unknown algorithm is not an error.
   /// </para>
   /// <para>
   /// This list used to say "CornerCrossing", which no version has ever written and the daemon
   /// has never understood. Keep it in step with <c>LbmOptionsViewModel.AlgorithmList</c> (the
   /// only thing that produces these values) and with <c>wire-contract/README.md</c>.
   /// </para>
   /// <para>
   /// "Strait" is a misspelling of "Straight" kept on purpose: renaming it would silently reset
   /// the algorithm of every existing configuration, so it stays until a migration exists on
   /// both sides. Only the internal Rust mode is spelled correctly (<c>Mode::Straight</c>).
   /// </para>
   /// </summary>
   string Algorithm { get; set; }

   /// <summary>
   /// Where bezel borders are stored: "PerModel" (default — shared by all monitors of the same
   /// make/model) or "PerMonitor" (each physical monitor keeps its own).
   /// </summary>
   string BorderValues { get; set; }

   /// <summary>
   /// The shortcut that frees a cursor trapped where no click can reach the UI, written
   /// the way it reads: "Ctrl+Alt+Shift+M". Held for about a second rather than tapped.
   /// Travels to the daemon with the layout, which is what registers it — see
   /// rust/crates/lbm-hook/src/shortcut.rs for the grammar both sides obey.
   /// </summary>
   string RescueShortcut { get; set; }


   /// <summary>
   /// Daemon process priority
   /// </summary>
   string Priority { get; set; }

   /// <summary>
   /// Daemon process priority when not hooked
   /// </summary>
   string PriorityUnhooked { get; set; }

   /// <summary>
   /// True if all sources have a pixel to dip ratio of 1
   /// </summary>
   bool IsUnaryRatio { get; set; }

   /// <summary>
   /// Mouse management enabled
   /// </summary>
   bool Enabled { get; set; }

   /// <summary>
   /// Allow software to check for updates online
   /// </summary>
   bool AutoUpdate { get; set; }

   /// <summary>
   /// Allow software sto start with user logon
   /// </summary>
   bool LoadAtStartup { get; set; }

   /// <summary>
   /// Experimental : Sleep monitors not containing mouse cursor after a delay 
   /// </summary>
   bool HomeCinema { get; set; }

   /// <summary>
   /// Keep ui window on top
   /// </summary>
   bool Pinned { get; set; }

   /// <summary>
   /// Start minimized in tray
   /// </summary>
   bool StartMinimized { get; set; }

   /// <summary>
   /// Start with elevated privileges
   /// </summary>
   bool StartElevated { get; set; }

   /// <summary>
   /// Hide the system tray icon
   /// </summary>
   bool HideTrayIcon { get; set; }

   /// <summary>
   /// Current elevated state
   /// </summary>
   bool Elevated { get; set; }

   /// <summary>
   /// Show debugging tools in the ui (virtual layout inspection...)
   /// </summary>
   bool DebugTools { get; set; }

   /// <summary>
   /// Show experimental features: Argyll color calibration and the
   /// smart-TV remote test tools of the VCP panel
   /// </summary>
   bool ExperimentalFeatures { get; set; }

   /// <summary>
   /// Show the VCP monitor-control panel (DDC/CI brightness, contrast, inputs,
   /// smart-TV remotes). Off by default: it talks to the monitors over DDC and
   /// most users only need the mouse-crossing features.
   /// </summary>
   bool VcpControl { get; set; }

   /// <summary>
   /// Ask for confirmation before monitor actions: attaching to the desktop,
   /// detaching, or making a monitor the primary display
   /// </summary>
   bool ShowMonitorActionWarning { get; set; }

   public bool LoopAllowed { get; }
   public ObservableCollection<string> ExcludedList { get; }
   bool Saved { get; set; }
}
